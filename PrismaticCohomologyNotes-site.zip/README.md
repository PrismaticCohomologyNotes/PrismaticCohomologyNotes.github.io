# Prismatic Cohomology Notes

《棱镜上同调：从基础、adic 与 rigid 几何到比较定理》的交互式中文学习工作台。

- 作者：LeoKwok
- 内容：32 章课程、章节检查点与参考答案、交叉引用、研究专题及完整 PDF 讲义
- 目标网址：<https://PrismaticCohomologyNotes.github.io/>

This repository contains the static GitHub Pages build. The editable source is maintained separately.
